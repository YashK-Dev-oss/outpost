## Unreleased

- Added accessible settings, optional audio and read-aloud helpers.
- Added inline base artwork, crew avatars, reduced-motion styling, and text sizing.
- Added readability, browser smoke, release validation, and classroom documentation.
# Changelog

## 0.1.0 - Phase 0

- Added the static OUTPOST repository scaffold and GitHub Pages entry point.
- Added the localized placeholder title screen, base theme tokens, server, smoke test, and CI workflow.
- Added Phase 1 game data, deterministic RNG helpers, validation checks, and provenance report generation.
- Added Phase 2 pure engine core for missions, jobs, resources, crew, sols, projections, scoring, and reports.
