# Progress

## Phase 0

Complete: repository scaffold, static title screen, CSS tokens, local server,
smoke test, data validation command, and CI workflow.

## Phase 1

Complete: game data schemas, provenance metadata, deterministic RNG, schema
validation, trade-off checks, string reference checks, and provenance reports.

Next: Phase 2 engine core.

Known issues: NASA real-data files remain empty until the live fetch tools run.
Scientific claims in Codex entries remain `[VERIFY]` pending human review.

## Phase 2

Complete: pure mission state creation, job assignment and effects, resource
resolution, crew dose and wellbeing, sol progression, projections, scoring,
mission reports, invariants, determinism, and non-mutation tests.

Deferred: schedules, weather, and emergencies remain out of scope for Phase 2.

## Phase 3

Implemented: deterministic schedules, weather state, forecasts, communication
delay handling, all four emergency clocks and effects, deadline forcing,
fixture tests, and balance-bot tooling.

Verification: `npm test` passes with 18 tests.

## Phase 5

Implemented: data loading, routing, store, settings, versioned saves, checkpoints,
localization helpers, live-region announcements, responsive command-loop screens,
meters, job planning, estimates, evening reports, and the emergency placeholder.
The existing pure engine API now drives mission creation, planning, resolution,
autosave, and sol progression. Full emergency interaction, playback, reports,
and learning screens remain scheduled for later phases.

Verification: `npm test` and `npm run validate` pass.

## Phase 4

Complete: NASA DONKI and JPL Horizons tools generated and validated all six
real-data files for windows A, B, and C. The DONKI endpoint uses the current
CCMC API route. Horizons parsing accepts the official space-separated table.

Verification: `npm run data:build`, `npm test`, and `npm run validate` pass.

## Phase 6

Implemented: interactive emergency clock, Ask Earth timing, option trade-offs,
damage display, action results, emergency lessons, paused and rewind choices,
evening results, and mission report routing. The command loop now connects
emergency actions to the pure engine.

## Phase 7

Implemented: Codex, Data Lab views backed by committed DONKI and Horizons JSON,
mission score/history report, training entry flow, credits attribution, and
read-aloud-ready localized screen text. Charts use serializable report history.

Known issue: browser speech and audio require a user gesture and remain off by default.

## Phase 8

Implemented: inline outpost cutaway artwork, crew avatars, optional WebAudio tones,
speech helpers, settings controls for text size, contrast, motion, sound, and
read-aloud, focus-visible styling, reduced-motion-safe animation, and friendly
loading errors.

## Phase 9

Implemented: browser smoke page, readability validator, release human-verification
gate, test plan, teacher guide, credits, and submission checklist.

Final automated checks: `npm test`, `npm run validate`, `npm run readability`,
`npm run validate -- --report`, browser smoke, syntax checks, and
`git diff --check` pass. The release gate remains intentionally blocked until
human Codex verification and real-device/child playtesting are complete.

Browser verification: a Cadet mission was played through all 30 sols,
including an emergency, and reached Mission Report without console errors.

Balance note: the existing bot harness now completes all 2,400 runs, but its
targets are not all met. GreedyScience pauses early as expected; Lazy and
Commander completion targets need tuning in a future balance pass.
