# Decisions

- Phase 0 uses the simplest static title screen and leaves gameplay modules as placeholders.
- Phase 1 keeps the existing empty `data/real/` files because NASA data must come from the live fetch tools; the validator checks their schemas when populated.
- Difficulty dust-storm start sols are not specified in section 2.6, so Phase 2 schedule generation will choose seeded starts from the listed durations and factors.
- `[VERIFY]` NASA facts remain out of the UI until real sources are fetched and human-verified.
- Phase 2 keeps `schedule` empty and does not resolve weather or emergencies; those behaviors begin in later phases.
- Engine timestamps use caller-provided `meta.createdAt` and `meta.updatedAt`; the pure engine never creates timestamps.
- Phase 3 exposes `emergencyForceDeadline` for deterministic development and deadline-path tests.
- NASA migrated DONKI from the legacy `api.nasa.gov/DONKI` route to the current CCMC `DONKI-API/get` route. The fetch tool uses the current documented route and does not place API keys in requests.
- JPL Horizons returns space-separated date/time and value columns in its official table. The parser accepts that shape and the earlier comma-separated fixture shape.
- Phase 8 graphics use inline SVG and CSS only. This avoids external assets, runtime network requests, and licensing uncertainty while keeping the outpost readable offline.
- The Phase 9 release gate intentionally remains red until a human fills Codex source, reviewer, and date fields. Device accessibility and child playtests are human-only checks.
- The final balance run is reported without changing game constants: the harness now handles invalid bot jobs safely, but Lazy and Commander targets still need a dedicated tuning pass.
- Phase 6 uses the existing checkpoint list for rewind choices; the simplest safe
  behavior restores the selected prior checkpoint and returns to Command.
- Phase 7 renders the committed real-data summaries without adding runtime
  network calls. Unverified Codex source metadata remains out of user-visible
  source links until human verification.
- Phase 8 keeps sound and speech off by default. Browser APIs are optional and activate only from a user-controlled setting or button.
- Phase 9 release validation intentionally fails until a human verifies the Codex entries; this is a required release gate, not a test failure to bypass.
