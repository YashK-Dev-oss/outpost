import { t } from "../../app/i18n.js";
export function eveningScreen({ state, report, onNext }) {
  const section = document.createElement("section"); section.className = "screen evening-screen";
  const h = document.createElement("h1"); h.textContent = `${t("ui.evening")}: ${state.sol}`; section.append(h);
  const list = document.createElement("ul"); [["ui.power", report?.power], ["ui.air", report?.air]].forEach(([key, value]) => { const li = document.createElement("li"); li.textContent = `${t(key)}: ${value}`; list.append(li); }); section.append(list);
  const button = document.createElement("button"); button.textContent = t("ui.nextSol"); button.onclick = onNext; section.append(button); return section;
}
