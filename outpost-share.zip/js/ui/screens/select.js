import { t } from "../../app/i18n.js";
export function selectScreen({ onStart, initialMode = "full" }) {
  const section = document.createElement("section"); section.className = "screen select-screen";
  const h = document.createElement("h1"); h.textContent = t("ui.missionSelect"); section.append(h);
  const form = document.createElement("form"); const name = document.createElement("input"); name.placeholder = t("ui.name"); name.maxLength = 16; name.setAttribute("aria-label", t("ui.name")); form.append(name);
  const choices = document.createElement("div"); choices.className = "choice-grid";
  ["cadet", "astronaut", "commander"].forEach((difficulty, index) => {
    const label = document.createElement("label"); const radio = document.createElement("input"); radio.type = "radio"; radio.name = "difficulty"; radio.value = difficulty; radio.checked = index === 1;
    label.append(radio, document.createTextNode(t(`ui.${difficulty}`))); choices.append(label);
  });
  form.append(choices); const classroom = document.createElement("label"); const toggle = document.createElement("input"); toggle.type = "checkbox"; classroom.append(toggle, document.createTextNode(t("ui.classroom"))); form.append(classroom);
  const start = document.createElement("button"); start.type = "submit"; start.textContent = t("ui.newMission"); form.append(start);
  if (initialMode === "training") { form.elements.difficulty.value = "cadet"; toggle.checked = false; }
  form.onsubmit = (event) => { event.preventDefault(); onStart({ difficulty: form.elements.difficulty.value, mode: initialMode === "training" ? "training" : toggle.checked ? "classroom" : "full", playerName: name.value }); };
  section.append(form); return section;
}
