import { t } from "../../app/i18n.js";
import { emergencyAct } from "../../engine/index.js";
export function emergencyScreen({ state, data, onAction }) {
  const section = document.createElement("section"); section.className = "screen emergency-screen";
  const config = data.emergencies[state.emergency.type];
  const h = document.createElement("h1"); h.textContent = `${config.icon} ${t(`em.${state.emergency.type}.title`)}`; section.append(h);
  const story = document.createElement("p"); story.textContent = t(`em.${state.emergency.type}.story`); section.append(story);
  const clock = document.createElement("p"); clock.setAttribute("role", "status"); clock.textContent = `${t("ui.clock")}: ${state.emergency.clockMin} / ${state.emergency.deadlineMin} min`; section.append(clock);
  const damage = Object.values(state.emergency.damage || {}).reduce((sum, value) => sum + Math.abs(value), 0);
  const waiting = document.createElement("p"); waiting.textContent = `${t("ui.damageWaiting", { damage: Math.round(damage) })} ${t("ui.earthReport", { minutes: state.emergency.roundTripMin / 2 })}`; section.append(waiting);
  const fact = document.createElement("p"); fact.textContent = t(`em.${state.emergency.type}.fact`); section.append(fact);
  const earth = document.createElement("button"); earth.textContent = `${t("ui.askEarth")} 🛰`; earth.disabled = state.emergency.askedEarth; earth.onclick = () => onAction("askEarth"); section.append(earth);
  const heading = document.createElement("h2"); heading.textContent = t("ui.chooseAction"); section.append(heading);
  for (const option of config.options) {
    const button = document.createElement("button");
    const advised = state.emergency.adviceOptionId === option.id ? " ✓" : "";
    button.textContent = `${option.id.replaceAll("_", " ")} · ${option.durationMin} min${advised}`;
    button.disabled = state.emergency.disabledOptions.includes(option.id);
    button.setAttribute("aria-label", t(option.tradeoffKey));
    button.onclick = () => onAction(option.id);
    section.append(button);
    const tradeoff = document.createElement("p"); tradeoff.textContent = t(option.tradeoffKey); section.append(tradeoff);
  }
  return section;
}
