import { t } from "../../app/i18n.js";
export function titleScreen({ onPlay, onContinue, hasSave, onCodex, onDataLab, onReport, onCredits, onTraining, onSettings }) {
  const section = document.createElement("section"); section.className = "title-screen";
  const h = document.createElement("h1"); h.textContent = t("title"); section.append(h);
  const team = document.createElement("p"); team.textContent = t("team"); section.append(team);
  const play = document.createElement("button"); play.textContent = t("ui.play"); play.onclick = onPlay; section.append(play);
  if (hasSave) { const button = document.createElement("button"); button.textContent = t("ui.continue"); button.onclick = onContinue; section.append(button); }
  [["ui.training", onTraining], ["ui.codex", onCodex], ["ui.dataLab", onDataLab], ["ui.credits", onCredits]].forEach(([key, action]) => { const button = document.createElement("button"); button.textContent = t(key); button.onclick = action; section.append(button); });
  const settings = document.createElement("button"); settings.textContent = t("ui.settings"); settings.onclick = onSettings; section.append(settings);
  if (hasSave && onReport) { const button = document.createElement("button"); button.textContent = t("ui.report"); button.onclick = onReport; section.append(button); }
  const disclaimer = document.createElement("p"); disclaimer.className = "disclaimer"; disclaimer.textContent = t("disclaimer"); section.append(disclaimer);
  return section;
}
