import { t } from "../../app/i18n.js";
import { getBriefing, getJobAvailability, autoAssign, previewPlan } from "../../engine/index.js";
import { crewCard } from "../components/crewCard.js";
import { baseView } from "../baseView.js";
import { announce } from "../../app/a11y.js";
function button(text, onClick) { const element = document.createElement("button"); element.textContent = text; element.onclick = onClick; return element; }
export function commandScreen({ state, data, onStart }) {
  const section = document.createElement("section"); section.className = "command screen";
  const h = document.createElement("h1"); h.textContent = t("ui.command"); section.append(h);
  const top = document.createElement("p"); top.textContent = t("ui.solOf", { sol: state.sol, total: state.totalSols }); section.append(top);
  const meters = document.createElement("div"); meters.className = "meter-strip";
  [["ui.power", state.resources.power], ["ui.air", state.resources.air], ["ui.shield", Math.floor(state.resources.shieldBlocks / data.constants.BLOCKS_PER_LAYER.value)]].forEach(([key, value]) => { const card = document.createElement("div"); card.className = "meter"; card.setAttribute("role", "meter"); card.setAttribute("aria-label", t(key)); card.textContent = `${t(key)}: ${value}`; meters.append(card); }); section.append(meters);
  const crew = document.createElement("div"); crew.className = "crew-row"; state.crew.forEach((member) => crew.append(crewCard(member, data.crew))); section.append(crew);
  section.append(baseView({ state, onExplain: () => announce(t("ui.baseHelp")) }));
  const briefing = getBriefing(state, data); const forecast = document.createElement("p"); forecast.textContent = briefing.forecast.length ? `${t("ui.forecast")}: ${briefing.forecast.map((item) => `${item.kind} ${item.solsUntil}`).join(", ")}` : t("ui.noForecast"); section.append(forecast);
  const slots = document.createElement("div"); slots.className = "slots";
  const plan = structuredClone(state.plan);
  const start = button(t("ui.startSol"), () => onStart(structuredClone(plan)));
  start.className = "primary";
  function syncSlots() {
    plan.slots.forEach((slot, index) => {
      const item = slots.children[index];
      item.textContent = slot.job
        ? `${index + 1}: ${t(data.jobs.find((job) => job.id === slot.job)?.nameKey ?? slot.job)}`
        : `${index + 1}: ${t("ui.autoPick")}`;
    });
    start.disabled = plan.slots.some((slot) => !slot.job);
  }
  plan.slots.forEach((slot, index) => {
    const item = document.createElement("button");
    item.type = "button";
    item.setAttribute("aria-label", t("ui.clearSlot", { slot: index + 1 }));
    item.onclick = () => { plan.slots[index].job = null; plan.slots[index].crewId = null; syncSlots(); };
    slots.append(item);
  });
  section.append(slots);
  const jobs = document.createElement("div"); jobs.className = "job-tray";
  const availability = getJobAvailability(state, data);
  data.jobs.forEach((job) => {
    const card = document.createElement("button");
    card.type = "button";
    card.textContent = `${job.icon} ${t(job.nameKey)}`;
    card.disabled = !availability[job.id]?.enabled;
    card.onclick = () => {
      const empty = plan.slots.find((slot) => !slot.job);
      if (!empty) return;
      empty.job = job.id;
      syncSlots();
    };
    jobs.append(card);
  });
  section.append(jobs);
  section.append(button(t("ui.autoPick"), () => {
    plan.slots = autoAssign(state, plan.slots.map((slot) => slot.job || "rest"));
    syncSlots();
  }));
  const maker = document.createElement("label"); const makerInput = document.createElement("input"); makerInput.type = "checkbox"; makerInput.checked = plan.airMakerOn; makerInput.onchange = () => { plan.airMakerOn = makerInput.checked; }; maker.append(makerInput, document.createTextNode(t("ui.airMaker"))); section.append(maker);
  const shelter = document.createElement("label");
  const shelterInput = document.createElement("input");
  shelterInput.type = "checkbox";
  shelterInput.checked = plan.shelter;
  shelterInput.disabled = !state.world.stormToday;
  shelterInput.onchange = () => { plan.shelter = shelterInput.checked; };
  shelter.append(shelterInput, document.createTextNode(t("ui.shelter")));
  section.append(shelter);
  section.append(start);
  const estimate = document.createElement("p"); estimate.className = "estimate"; const preview = previewPlan(state, plan, data); estimate.textContent = `${t("ui.estimate")}: ${t("ui.power")} ${preview.state.resources.power}, ${t("ui.air")} ${preview.state.resources.air}`; section.append(estimate);
  syncSlots();
  return section;
}
