import { t } from "../app/i18n.js";

const SVG_NS = "http://www.w3.org/2000/svg";

function node(name, attributes = {}) {
  const element = document.createElementNS(SVG_NS, name);
  Object.entries(attributes).forEach(([key, value]) => element.setAttribute(key, String(value)));
  return element;
}

function label(text, x, y, className = "base-label") {
  const element = node("text", { x, y, class: className });
  element.textContent = text;
  return element;
}

/** Render the outpost cutaway without external image assets. */
export function baseView({ state, onExplain } = {}) {
  const svg = node("svg", {
    viewBox: "0 0 800 430",
    role: "img",
    "aria-label": t("ui.baseView"),
    class: "base-art"
  });
  svg.append(
    node("rect", { width: 800, height: 430, rx: 24, class: "base-sky" }),
    node("circle", { cx: 690, cy: 68, r: 34, class: "base-sun" }),
    node("path", { d: "M0 300 Q160 245 320 300 T640 285 T800 300 V430 H0Z", class: "base-ground" })
  );

  const panels = node("g", { class: "base-hotspot", tabindex: "0", role: "button", "aria-label": t("ui.solarPanels") });
  panels.append(
    node("path", { d: "M74 145 L255 104 L274 171 L92 214 Z", class: "solar-panel" }),
    node("path", { d: "M110 137 L128 198 M151 128 L169 188 M192 119 L210 180 M90 162 L264 124 M99 188 L270 150", class: "panel-lines" }),
    label(t("ui.solarPanels"), 105, 235)
  );
  panels.onclick = () => onExplain?.("power");
  panels.onkeydown = (event) => { if (event.key === "Enter" || event.key === " ") onExplain?.("power"); };
  svg.append(panels);

  const base = node("g", { class: "base-hotspot", tabindex: "0", role: "button", "aria-label": t("ui.outpostBase") });
  base.append(
    node("rect", { x: 290, y: 170, width: 285, height: 150, rx: 26, class: "base-building" }),
    node("path", { d: "M272 174 L432 91 L592 174", class: "base-roof" }),
    node("rect", { x: 408, y: 227, width: 54, height: 93, rx: 8, class: "base-door" }),
    node("circle", { cx: 432, cy: 215, r: 10, class: state?.resources?.airMaker?.on ? "lamp lamp-on" : "lamp lamp-off" }),
    label(t("ui.outpostBase"), 369, 350)
  );
  svg.append(base);

  const maker = node("g", { class: "base-hotspot", tabindex: "0", role: "button", "aria-label": t("ui.airMaker") });
  maker.append(
    node("rect", { x: 520, y: 194, width: 40, height: 70, rx: 8, class: "maker-tank" }),
    node("path", { d: "M540 194 V168 M528 168 H552", class: "maker-pipe" }),
    label(t("ui.airMaker"), 505, 286)
  );
  maker.onclick = () => onExplain?.("air");
  maker.onkeydown = (event) => { if (event.key === "Enter" || event.key === " ") onExplain?.("air"); };
  svg.append(maker);

  const layers = Math.min(3, Math.floor((state?.resources?.shieldBlocks ?? 0) / 6));
  const shield = node("g", { class: "base-shield", "aria-label": t("ui.shield") });
  for (let index = 0; index < layers; index += 1) {
    shield.append(node("rect", { x: 285 - index * 6, y: 310 - index * 12, width: 295 + index * 12, height: 12, rx: 5, class: "shield-block" }));
  }
  shield.append(label(t("ui.shield"), 620, 334));
  svg.append(shield);

  const shelter = node("g", { class: "base-shelter", "aria-label": t("ui.shelter") });
  shelter.append(node("rect", { x: 630, y: 245, width: 110, height: 72, rx: 24, class: "shelter-dome" }), label(t("ui.shelter"), 642, 342));
  svg.append(shelter);

  const dust = Math.min(0.65, (state?.resources?.dust ?? 0) / 100);
  svg.append(node("rect", { width: 800, height: 430, rx: 24, class: "dust-haze", opacity: dust }));
  return svg;
}
