export function meter(label, value, max = 100) {
  const element = document.createElement("div"); element.className = "meter"; element.setAttribute("role", "meter"); element.setAttribute("aria-label", label); element.setAttribute("aria-valuenow", value); element.setAttribute("aria-valuemax", max); element.textContent = `${label}: ${value}`; return element;
}
