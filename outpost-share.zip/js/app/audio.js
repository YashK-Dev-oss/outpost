let context;
const tones = { tap: [440, 0.06], alert: [220, 0.16], success: [660, 0.12] };

/** Play a short, optional interface tone. */
export function tone(kind = "tap", enabled = false) {
  if (!enabled || typeof AudioContext === "undefined") return;
  const [frequency, duration] = tones[kind] || tones.tap;
  context ||= new AudioContext();
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.frequency.value = frequency;
  gain.gain.setValueAtTime(0.04, context.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration);
  oscillator.connect(gain).connect(context.destination);
  oscillator.start();
  oscillator.stop(context.currentTime + duration);
}
